let order = {
    user: {
        name: "Павел",
        surname: "Волков",
        email: "p-volkoff@mail.ru",
        phone: "8(912)552-92-25"
    },
    order_info: {
        order_date: "07.01.2023",
        delivery_type: "По адресу",
        discount: "10%",
        total_price: "",
        address: {
            city: "Москва",
            street: "Белореченская улица",
            house: "31"
        }
    },
    products: [
        {
            articul: "RTLACB138001",
            name: "Носки из хлопка SUPIMA",
            brand: "UNIQLO",
            color: "Синий",
            season: "Мульти",
            price: 399,
            quantity: 3,
            cost: ""
        },
        {
            articul: "MP002XM0984Y",
            name: "Брюки",
            brand: "O'stin",
            color: "Черный",
            season: "Демисезон",
            price: 3799,
            quantity: 1,
            cost: ""
        },
        {
            articul: "MP002XM0984Y",
            name: "Дубленка CLAUDE",
            brand: "Mango Man",
            color: "Коричневый",
            season: "Мульти",
            price: 11190,
            quantity: 1,
            cost: ""
        }
    ]
};
let jsonOrder = JSON.stringify(order);
console.log("1. JSON-представление заказа:");
console.log(jsonOrder);
let parsedOrder = JSON.parse(jsonOrder);

let totalPrice = 0;
parsedOrder.products.forEach(product => {
    product.cost = product.price * product.quantity;
    totalPrice = totalPrice + product.cost;
});
let discountPercent = parseFloat(parsedOrder.order_info.discount);
let finalPrice = totalPrice - (totalPrice * (discountPercent / 100));
parsedOrder.order_info.total_price = finalPrice;
console.log("2. Объект JS с расчетами:");
console.log(parsedOrder);
document.addEventListener('DOMContentLoaded', () => {
    const container = document.createElement('div');
    container.className = 'order-container';
    const header = document.createElement('div');
    header.className = 'header';
    header.textContent = `Заказ пользователя: ${parsedOrder.user.name} ${parsedOrder.user.surname}`;
    container.append(header);
    const userInfo = document.createElement('div');
    userInfo.innerHTML = `
        <div class="user-info"><span>Номер телефона</span><span>${parsedOrder.user.phone}</span></div>
        <div class="user-info"><span>E-mail</span><span>${parsedOrder.user.email}</span></div>
        <div class="order-details"><span>Дата заказа</span><span>${parsedOrder.order_info.order_date}</span></div>
        <div class="order-details"><span>Тип доставки</span><span>${parsedOrder.order_info.delivery_type} (${parsedOrder.order_info.address.city}, ${parsedOrder.order_info.address.street} ${parsedOrder.order_info.address.house})</span></div>
        <div class="order-details"><span>Скидка</span><span>${parsedOrder.order_info.discount}</span></div>
    `;
    container.append(userInfo);
    parsedOrder.products.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.className = 'product';
        productDiv.innerHTML = `
            <div class="product-info">
                Артикул: ${product.articul}<br>
                Название: ${product.name}<br>
                Бренд: ${product.brand}<br>
                Цвет: ${product.color}<br>
                Сезон: ${product.season}<br>
                Цена: ${product.price} ₽
            </div>
            <div class="product-qty">- ${product.quantity} +</div>
            <div class="product-cost">${product.cost} ₽</div>
        `;
        container.append(productDiv);
    });
    const totalsDiv = document.createElement('div');
    totalsDiv.className = 'totals';
    totalsDiv.innerHTML = `
        Итого: ${totalPrice} ₽<br>
        Итого (со скидкой): ${finalPrice} ₽
    `;
    container.append(totalsDiv);
    document.body.insertBefore(container, document.body.firstChild);
});