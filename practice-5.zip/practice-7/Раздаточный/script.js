document.addEventListener('DOMContentLoaded', () => {
    // Берем случайный город
    const randomIndex = Math.floor(Math.random() * seven.length);
    const randomWonder = seven[randomIndex];

    const mainContainer = document.getElementById('random-wonder');

    const h2 = document.createElement('h2');
    h2.textContent = randomWonder.name;

    const imagesContainer = document.createElement('div');
    imagesContainer.className = 'images-container';
    
    randomWonder.images.forEach(imgData => {
        const img = document.createElement('img');
        img.src = imgData.src;
        img.alt = imgData.title;
        img.className = 'wonder-img';
        imagesContainer.append(img);
    });

    const descContainer = document.createElement('div');
    descContainer.className = 'description';
    descContainer.innerHTML = randomWonder.description;

    mainContainer.append(h2, imagesContainer, descContainer);

    const listContainer = document.getElementById('wonders-list');
    
    seven.forEach(wonder => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        
        a.textContent = wonder.title;
        a.href = wonder.href; 
        a.target = '_blank';
        
        li.append(a);
        listContainer.append(li);
    });
});